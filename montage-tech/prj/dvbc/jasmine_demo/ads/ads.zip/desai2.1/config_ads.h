/********************************************************************************************/
/* Copyright (c) 2014 Montage Technology Group Limited and its affiliated companies         */
/* Montage Proprietary and Confidential                                                     */
/* Montage Technology (Shanghai) Co., Ltd.                                                  */
/********************************************************************************************/
#ifndef __ADS_FUNTION_PUBLIC_H__
#define __ADS_FUNTION_PUBLIC_H__

#define CONFIG_ADS_ID 
void ads_ap_init(void);
u8* ads_get_ad_version(void);
void ui_close_ad_logo(void);
#endif